
## *[title]* 
#### *[name]* 
#### *[student id]* 

## Proposal
### Motivation
*[Clearly motivate the purpose of your project; why someone would care about what you are doing]*



### Aims
*[Clearly state what the project is intended to do. This should be something which is measurable; it should be possible to tell if you succeeded]*




## Progress
*[Briefly state your progress so far, as a bulleted list]*


## Problems and risks
### Problems
*[What problems have you had so far, that have held up the project?]*


### Risks
*[What problems do you foresee in the future and how will you mitigate them?]*


## Plan
*[Time plan, in roughly weekly to monthly blocks, up until submission week]*


